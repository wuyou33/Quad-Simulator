%% Mathematical model vs Simulink model %
% Autor: Mattia Giurato                 %
% Last review: 2015/03/31               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all 
clc

%% Parameters definition
D = 12*(2.54/100);              %[m] Propeller diameter
Ct = 3.0314e-05;                %[] Thrust coefficient
ro = 1.225;                     %[kg*m^-3] Air density

x1 = [51.5329 1.1614e+03]';     %RPM vs THROTTLE, Y = m*X + q, x1 = [m q]    
x2 = 3.2051e-07;
Throttle = [10 20 30 40 50 60 70 80 90 100]';


%% main
Omega = x1(1)*Throttle + x1(2);
P2 = x2*Omega.^2;

sim b_ESC_BL_Prop

plot(Throttle, P2, tout, yout)
grid
title('Thrust vs Throttle')
legend('Data', 'Simulink')
ylabel('[N]')
xlabel('[RPM]')

