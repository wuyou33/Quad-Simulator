%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Kalman Position - Simulator    %
% Authors: A.Sorbelli, M.Giurato %
% Date: 16/05/30                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
clc

%% Load data
load fly7_tuning.mat

ts = 0.01;
t = 0:ts:(length(acc)-1)*ts;
Tsim = max(t);

%% Rotate IMU frame to the body frame
phi = pi;
theta = 0;
psi = pi/2;

Sphi = sin(phi);
Cphi = cos(phi);
Stheta = sin(theta);
Ctheta = cos(theta);
Spsi = sin(psi);
Cpsi = cos(psi);


Rx = [1   0    0   ;
      0  Cphi Sphi ;
      0 -Sphi Cphi];
Ry = [Ctheta 0 -Stheta ;
        0    1    0    ;
      Stheta 0  Ctheta];
Rz = [ Cpsi Spsi 0 ;
      -Spsi Cpsi 0 ;
        0    0   1];

acc_bias = mean(acc(1:100,1:2));

acc = acc - ones(size(acc))*diag([acc_bias 0]);

acc_scale = mean(acc(1:100,3));

Acc_IMU = acc'./acc_scale;

Acc_body = Rx*Ry*Rz * Acc_IMU;
Acc_body = Acc_body' * 9.81;

%% Rotate Acc_body to Earth frame
phi = OPTI_RPY(:,1)*pi/180;
theta = OPTI_RPY(:,2)*pi/180;
psi = OPTI_RPY(:,3)*pi/180;

Sphi = sin(phi);
Cphi = cos(phi);
Stheta = sin(theta);
Ctheta = cos(theta);
Spsi = sin(psi);
Cpsi = cos(psi);

AccEarth = zeros(size(Acc_body));
for i = 1:length(phi)
    Rx = [1     0       0    ;
          0  Cphi(i) Sphi(i) ;
          0 -Sphi(i) Cphi(i)];
    Ry = [Ctheta(i) 0 -Stheta(i) ;
             0      1      0     ;
          Stheta(i) 0  Ctheta(i)];
    Rz = [ Cpsi(i) Spsi(i) 0 ;
          -Spsi(i) Cpsi(i) 0 ;
              0       0    1];
    Tbet = (Rx*Ry*Rz)';
    
    accearth = Tbet * Acc_body(i,:)';
    AccEarth(i,:) = accearth' + [0 0 9.81];
end

%% Simulate Kalition
Acc_Earth = timeseries(AccEarth,t);
pos_n = timeseries(Ned(:,1),t);
pos_e = timeseries(Ned(:,2),t);

Q = diag([0.005 0.005 0.005]);
sigma_acc = 0.3;
sigma_opti = 1;
R = diag([sigma_acc^2 sigma_opti^2]);
    
sim Kalition_test

figure('name','position')
subplot(211)
hold on
plot(pos_n)
plot(n_dist)
grid minor
ylabel('North [m]')
subplot(212)
hold on
plot(pos_e)
plot(e_dist)
grid minor
legend('Optitrack','Kalman','location','northeast')
ylabel('East [m]')
xlabel('time [s]')

%% Chillin' for a while after a long journey
load handel;
player = audioplayer(y, Fs);
play(player);

%% END OF CODE